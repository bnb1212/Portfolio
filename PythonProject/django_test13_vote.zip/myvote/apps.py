from django.apps import AppConfig


class MyvoteConfig(AppConfig):
    name = 'myvote'
